package com.cfsuman.jetpackcompose

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Column
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


            setContent {
                MessageCard("Welcome to my space")
            }
        }
    }


    @Composable
    fun MessageCard(name: String) {
        Text(text = "Hello $name!")
    }
@Preview
@Composable
fun DefaultPreview() {


    ExtendedFloatingActionButton(
        onClick = {
            var applicationContext = null
            Toast.makeText(applicationContext, "You clicked the Button.", Toast.LENGTH_LONG).show()
        },
        icon = {
            Icon(



                Icons.Filled.Favorite,
                contentDescription = "Info",

                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .padding(20.dp)



            )

        },

        text = { Text("Info")
        }
    )
}

