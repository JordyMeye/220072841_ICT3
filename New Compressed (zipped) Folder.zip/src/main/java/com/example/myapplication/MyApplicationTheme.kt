package com.example.myapplication

class MyApplicationTheme(function: () -> Unit) {

}
